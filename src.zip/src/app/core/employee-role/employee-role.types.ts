export interface Role {
  id: number;
  name: string;
  description:string;
  permissions: Permise[];
}

export interface ExRole {
  id: number;
  name: string;
  description:string;
  permission_ids: any;
}

// permission.model.ts

export interface Permission {
    id: number;
    name: string;
    description: string;
    permission_type: string; // Adjust as per your API response
  }
  
export interface Permise {
    id: number;
    name: string;
    completed: boolean;
  }