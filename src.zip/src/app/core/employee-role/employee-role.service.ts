import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { ExRole, Permission, Role } from './employee-role.types';


@Injectable({
  providedIn: 'root'
})
export class EmployeeRoleService {
  private baseUrl = 'http://localhost:4200'; // Adjust according to your Laravel base URL
  
  constructor(private http: HttpClient) { }

  // Get all roles
  getRoles(): Observable<Role[]> {
    return this.http.get<{ data: Role[] }>(`${this.baseUrl}/api/employee/roles`)
      .pipe(
        map(response => response.data), // Map to extract data property
        catchError(this.handleError)
      );
  }
  
  
  //  delete the employee Role
  deleteRole(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/api/employee/roles/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  createRole(roleData: any): Observable<any> {
    let params = new HttpParams()
      .set('name', roleData.name)
      .set('description', roleData.description);

    roleData.permissions.forEach((permission: number) => {
      params = params.append('permission[]', String(permission));
    });

    return this.http.post(`${this.baseUrl}/api/employee/roles`, null, { params })
      .pipe(
        catchError(this.handleError)
      );
  }
  

  updateRole(id: number, updatedRole: any): Observable<any> {
    let params = new HttpParams()
      .set('name', updatedRole.name)
      .set('description', updatedRole.description);

    updatedRole.permissions.forEach((permission: number) => {
      params = params.append('permission[]', String(permission));
    });

    return this.http.put(`${this.baseUrl}/api/employee/roles/${id}`, null, { params })
      .pipe(
        catchError(this.handleError)
      );
  }

   
  getPermissions(): Observable<Permission[]> {
    return this.http.get<{ data: Permission[] }>(`/api/employee/roles/permissions`)
      .pipe(
        map(response => response.data), // Extract data property from response
        catchError(this.handleError)
      );
  }
  
  
  getRoleById(id: number): Observable<ExRole> {
    return this.http.get<ExRole>(`${this.baseUrl}/api/employee/roles/${id}`).pipe(
      catchError(this.handleError)
    );
  }
   
  // Handle HTTP errors
  private handleError(error: HttpErrorResponse): Observable<never> {
    console.error('An error occurred:', error.message);
    return throwError(() => error);
  }
}
