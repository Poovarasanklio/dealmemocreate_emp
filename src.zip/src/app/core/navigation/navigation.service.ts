import { inject, Injectable } from '@angular/core';
import { Navigation } from 'app/core/navigation/navigation.types';
import { Observable, ReplaySubject, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class NavigationService {
    private _navigation: ReplaySubject<Navigation> =
        new ReplaySubject<Navigation>(1);

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for navigation
     */
    get navigation$(): Observable<Navigation> {
        return this._navigation.asObservable();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Get all navigation data
     */
    // get(): Observable<Navigation> {
    //     return this._httpClient.get<Navigation>('api/common/navigation').pipe(
    //         tap((navigation) => {
    //             this._navigation.next(navigation);
    //         })
    //     );
    // }

    get(): Observable<Navigation> {
        const navigationData: Navigation = {
            compact: [
                {
                    id: 'example',
                    title: 'Example',
                    type: 'basic',
                    icon: 'heroicons_outline:chart-pie',
                    link: '/example',
                },
            ],
            default: [
                {
                    id: 'example',
                    title: 'Example',
                    type: 'basic',
                    icon: 'heroicons_outline:chart-pie',
                    link: '/example',
                },
                {
                    id: 'testing',
                    title: 'Testing',
                    type: 'basic',
                    icon: 'heroicons_outline:user',
                    link: '/testing',
                },
                {
                    id   : 'employee-list',
                    title: 'Employee List',
                    type : 'basic',
                    icon : 'heroicons_outline:users',
                    link : '/employee-list'
                },
                {
                    id   : 'employee-role-list',
                    title: 'Employee Roles',
                    type : 'basic',
                    icon : 'heroicons_outline:wrench-screwdriver',
                    link : '/employee-role-list'
                },
                {
                    id   : 'artists-list',
                    title: 'Artists List',
                    type : 'basic',
                    icon : 'heroicons_outline:wrench-screwdriver',
                    link : '/artists-list'
                },
            ],
            futuristic: [
                {
                    id: 'example',
                    title: 'Example',
                    type: 'basic',
                    icon: 'heroicons_outline:chart-pie',
                    link: '/example',
                },
            ],
            horizontal: [
                {
                    id: 'example',
                    title: 'Example',
                    type: 'basic',
                    icon: 'heroicons_outline:chart-pie',
                    link: '/example',
                },
            ],
        };

        // Emit the navigation data
        this._navigation.next(navigationData);

        // Return the navigation data as an observable
        return of(navigationData);
    }
}
