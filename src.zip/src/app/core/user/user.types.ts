export interface User {
    id: string;
    name: string;
    email: string;
    agency_id: string;
    agency_name: string;
    role_name: string;
    is_owner: string;
    avatar?: string;
    status?: string;
}
