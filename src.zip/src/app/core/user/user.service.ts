import { Injectable } from '@angular/core';
import { User } from 'app/core/user/user.types';
import { Observable, ReplaySubject, of } from 'rxjs';
import { tap, map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class UserService {
    private _user: ReplaySubject<User> = new ReplaySubject<User>(1);
    // User local Storage Key
    private readonly USER_STORAGE_KEY = 'user';

    constructor() {
        // Retrieve user data from localStorage if available
        const storedUserData = localStorage.getItem(this.USER_STORAGE_KEY);
        if (storedUserData) {
            this._user.next(JSON.parse(storedUserData));
        } else {
            // If no data in localStorage, use default mock data
            const mockUserData: User = {
                id: '',
                name: '',
                email: '',
                agency_id: '',
                agency_name: '',
                role_name: '',
                is_owner: '',
                avatar: '',
                status: '',
            };
            this._user.next(mockUserData);
        }
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Setter & getter for user
     *
     * @param value
     */
    set user(value: User) {
        // Store the value
        this._user.next(value);
        localStorage.setItem(this.USER_STORAGE_KEY, JSON.stringify(value));
    }

    get user$(): Observable<User> {
        return this._user.asObservable();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Get the current signed-in user data
     */
    get(): Observable<User> {
        const storedUserData = localStorage.getItem(this.USER_STORAGE_KEY);
        const user = storedUserData ? JSON.parse(storedUserData) : null;
        return of(user).pipe(
            tap((user) => {
                this._user.next(user);
            })
        );
    }

    /**
     * Update the user
     *
     * @param user
     */
    update(user: User): Observable<any> {
        // Update the mock user data with the new user data
        const updatedUser = { ...user };
        
        localStorage.setItem(this.USER_STORAGE_KEY, JSON.stringify(updatedUser));
        return of(updatedUser).pipe(
            tap((response) => {
                this._user.next(response);
            })
        );
    }
}
