import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,map  } from 'rxjs/operators';
import { UserData, EmployeeResponse ,EmployeeRole} from 'app/core/employee/employee.types'; // Adjust the path as needed

@Injectable({
  providedIn: 'root'
})
export class CreateEmployeeService {
  private baseUrl = 'http://localhost:4200'; // Adjust according to your Laravel base URL
  // private authKey =  'auth_key eyJpdiI6IjJkL2x6VldGdUZIcUtGVy9LODFnUlE9PSIsInZhbHVlIjoiMjdnblN3bkM0Sm9ZTXJPYTZ2QndSdz09IiwibWFjIjoiYzRlODg3MmY0MTU0MzFjZDMxZmU4ZDkwODA1NTM2MmE3MjVmOTNmZWRmODcxMWRhM2Y4NDE0YTUzNDdlNzBhYSIsInRhZyI6IiJ9'; // Replace with your actual authentication key

  constructor(private http: HttpClient) {}

  // private getHeaders(): HttpHeaders {
  //   return new HttpHeaders({
  //     'Authorization': `Bearer ${this.authKey}`,
  //     'Content-Type': 'application/json'
  //   });
  // }

  // Create a new employee
  createEmployee(employeeData: UserData): Observable<any> {
    // const headers = this.getHeaders();
    return this.http.post(`${this.baseUrl}/api/employee`, employeeData)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Get all employees
  getEmployees(): Observable<EmployeeResponse> {
    // const headers = this.getHeaders();
    return this.http.get<EmployeeResponse>( `${this.baseUrl}/api/employee`)
      .pipe(
        catchError(this.handleError)
      );
  }

  getEmployeeById(id: string): Observable<UserData> {
    return this.http.get<UserData>(`${this.baseUrl}/api/employee/${id}`)
    .pipe(
      catchError(this.handleError)
    );
}


  // Update an existing employee
  updateEmployee(employeeId: number, employeeData: UserData): Observable<any> {
    // const headers = this.getHeaders();
    return this.http.put(`${this.baseUrl}/api/employee/${employeeId}`, employeeData)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Delete an employee
  deleteEmployee(employeeId: number): Observable<any> {
    // const headers = this.getHeaders();
    return this.http.delete(`${this.baseUrl}/api/employee/${employeeId}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Reset the password of an employee employee/{id}/reset_password
  resetPassword(employeeId: number): Observable<any> {
    // const headers = this.getHeaders();
    return this.http.post(`${this.baseUrl}/api/employee/${employeeId}/reset_password`, {})
    .pipe(
      catchError(this.handleError)
    );
  }
  
  // New method to get roles
  getRoles(): Observable<EmployeeRole[]> {
    // const headers = this.getHeaders();
    return this.http.get<{ data: EmployeeRole[] }>(`${this.baseUrl}/api/employee/roles`)
    .pipe(
      map(response => response.data)
    );
  }
  
  filterEmployeesByName(name: string): Observable<EmployeeResponse> {
    // const headers = this.getHeaders();
    return this.http.get<EmployeeResponse>(`${this.baseUrl}/api/employee?name=${name}`)
 
  }


  // Handle errors
  private handleError(error: HttpErrorResponse): Observable<never> {
    console.error('An error occurred:', error.message);
    return throwError(() => error);
  }
}


// , { headers }