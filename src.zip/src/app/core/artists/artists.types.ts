export interface  ArtistsResponse{
    data: ArtistsReport[];
  }


  export interface ArtistsReport{
      id : number,
      name : string ,
      category_id : number,
      category_name : string ,
      status : string ,
      email : string ,
      business_name : string ,
      street_address : string ,
      city : string ,
      state : string ,
      zipcode : number 
}           
 
export interface Artist {
  artist_name: string;
  artist_category_id: number;
  business_name?: string;
  email?: string;
  street_address?: string;
  city?: string;
  state?: string;
  zipcode?: string;
}


  // artists.types.ts
export interface ArtistCategory {
    id: number;
    category_name: string;
    is_default: number;
    is_other: number;
  }
  