import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Artist, ArtistCategory, ArtistsReport, ArtistsResponse } from './artists.types';
 
@Injectable({
  providedIn: 'root'
})
export class ArtistsService {
 
  private baseUrl = 'http://localhost:4200'; // Adjust according to your Laravel base URL
  getClients: any;
  constructor(private http: HttpClient) {}


  // Get all Artists
  getArtists(): Observable<ArtistsResponse > {
    return this.http.get<ArtistsResponse>( `${this.baseUrl}/api/artists`)
    .pipe(
      catchError(this.handleError)
    );
  }
  // Get all ArtistsCategory

  getCategories(): Observable<{data: ArtistCategory[]}> {
    return this.http.get<{data: ArtistCategory[]}>(`/api/artists/categories`)
      .pipe(
        catchError(this.handleError)
      );
  }

  getFilteredArtists(params: any): Observable<ArtistsResponse> {
    let httpParams = new HttpParams();

    // Dynamically set query parameters
    Object.keys(params).forEach(key => {
      console.log('Object',params);
      console.log('key',key);
      
      if (params[key]) {
        httpParams = httpParams.set(key, params[key]);
        console.log('httpParams',httpParams);
      }
    });
    console.log('params',params);
    
    return this.http.get<ArtistsResponse>(`${this.baseUrl}/api/artists`, { params: httpParams })
      .pipe(
        catchError(this.handleError)
      );
 
  }
  //  delete the artists
  
  deleteArtist(artistId: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/api/artists/${artistId}`)
      .pipe(
        catchError(this.handleError)
      );
  }


  // Create a new artist
  createArtist(artistData: Artist): Observable<any> {
    console.log('artistData [post http',artistData);
    
    return this.http.post<any>(`${this.baseUrl}/api/artists`, artistData)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Update an existing artist
  updateArtist(artistId: number, artistData: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/artists/${artistId}`, artistData)
      .pipe(
        catchError(this.handleError)
      );
  }
 
  // Get artist details by ID
  getArtistById(artistId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/artists/${artistId}`)
      .pipe(
        catchError(this.handleError)
      );
  }
  
   // Handle errors
   private handleError(error: HttpErrorResponse): Observable<never> {
    console.error('An error occurred:', error.message);
    return throwError(() => error);
  }

}