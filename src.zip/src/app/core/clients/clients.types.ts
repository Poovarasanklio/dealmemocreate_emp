export interface  ClientsResponse{
    data: ClientsReport[];
  }


  export interface ClientsReport{
      id : number,
      name : string ,
      category_id : number,
      category_name : string ,
      status : string ,
      email : string ,
      contact_name : string ,
      street_address : string ,
      city : string ,
      state : string ,
      zipcode : number 
}           
  export interface clients{
      client_name : string ,
      client_category_id : number,
      contact_name : string ,
      status : string ,
      email : string ,
      street_address : string ,
      city : string ,
      state : string ,
      zipcode : number 
}           


export interface SubClientsReport{
  id: number,
  client_id: number,
  name: string,
  email: string ,
  type: string ,
  sub_client_particulars:string  
}



  // artists.types.ts
export interface ClientsCategory {
    id: number;
    category_name: string;
    is_default: number;
    is_other: number;
  }
