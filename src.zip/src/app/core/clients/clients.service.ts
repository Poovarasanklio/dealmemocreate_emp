import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { clients, ClientsCategory, ClientsReport, ClientsResponse, SubClientsReport } from './clients.types';

@Injectable({
  providedIn: 'root'
})
export class ClientsService {

  private baseUrl = 'http://localhost:4200'; // Adjust according to your Laravel base URL
  constructor(private http: HttpClient) {}


   // Get all Clients
   getClients(): Observable<ClientsResponse > {
    return this.http.get<ClientsResponse>( `${this.baseUrl}/api/clients`)
    .pipe(
      catchError(this.handleError)
    );
  }

   // Get SubClients
  getSubClients(client_id: number): Observable<{ data: SubClientsReport[] }> {
    return this.http.get<{ data: SubClientsReport[] }>(`${this.baseUrl}/api/clients/${client_id}/subclients`)
      .pipe(
        catchError(this.handleError)
      );
  }
  

    // Method to get the category data
    getCategories(): Observable<{data:ClientsCategory[]}> {
      return this.http.get<{data:ClientsCategory[]}>(`${this.baseUrl}/api/clients/categories`)
      .pipe(
        catchError(this.handleError)
      );
    }

    //  delete the client
    deleteClient(clientId: number): Observable<any> {
      return this.http.delete<any>(`${this.baseUrl}/api/clients/${clientId}`)
        .pipe(
          catchError(this.handleError)
        );
    }

    getFilteredClients(params: any): Observable<ClientsResponse> {
      let httpParams = new HttpParams();
  
      // Dynamically set query parameters
      Object.keys(params).forEach(key => {
        console.log('Object',params);
        console.log('key',key);
        
        if (params[key]) {
          httpParams = httpParams.set(key, params[key]);
          console.log('httpParams',httpParams);
        }
      });
      console.log('params',params);
      
      return this.http.get<ClientsResponse>(`${this.baseUrl}/api/clients`, { params: httpParams })
        .pipe(
          catchError(this.handleError)
        );
   
    }

     // Create a new client
  createClient(ClientData: clients): Observable<any> {
    console.log('clientData [post http',ClientData);
    
    return this.http.post<any>(`${this.baseUrl}/api/clients`, ClientData)
      .pipe(
        catchError(this.handleError)
      );
  }


   // Update an existing artist
   updateClient(clientId: number, clientData: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/clients/${clientId}`, clientData)
      .pipe(
        catchError(this.handleError)
      );
  }
 
  // Get artist details by ID
  getClientById(clientId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/clients/${clientId}`)
      .pipe(
        catchError(this.handleError)
      );
  }


  private handleError(error: HttpErrorResponse): Observable<never> {
    console.error('An error occurred:', error.message);
    return throwError(() => error);
  }

}
