// src/app/modules/admin/employee-form/employee-form.routes.ts
import { Route } from '@angular/router';
import { EmployeeFormComponent } from './employee-form.component';

export const employeeFormRoutes: Route[] = [
    { path: '', component: EmployeeFormComponent }
];
