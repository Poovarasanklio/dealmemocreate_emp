import { ChangeDetectionStrategy, Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { TextFieldModule } from '@angular/cdk/text-field';
import { CreateEmployeeService } from 'app/core/employee/employee.service';
import { UserData, EmployeeRole } from 'app/core/employee/employee.types';
import { MatIconModule } from '@angular/material/icon';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TextFieldModule,
    MatSelectModule,
    MatOptionModule,
    MatButtonModule,
    CommonModule,
    FuseAlertComponent,
    RouterModule
  ],
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.scss']
})

export class EmployeeFormComponent implements OnInit {

  newEmployeeForm: FormGroup;
  fieldErrors: { [key: string]: string } = {};
  roles: EmployeeRole[] = []; // Changed to hold roles fetched from API
  selectedEmployee: UserData | null = null;
  showAlert: boolean = false;
  verificationMessage: string = '';
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };

  @ViewChild('nameInput') nameInput: ElementRef;
  @ViewChild('addressInput') addressInput: ElementRef;
  @ViewChild('emailInput') emailInput: ElementRef;
  @ViewChild('mobile_numberInput') mobile_numberInput: ElementRef;
  @ViewChild('roleidInput') roleidInput: MatSelect;

  constructor(
    private _formBuilder: FormBuilder, 
    private createEmployeeService: CreateEmployeeService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef) { }


  ngOnInit(): void {
    this.newEmployeeForm = this._formBuilder.group({
      name: ['',Validators.required],
      address: ['',Validators.required],
      email: ['',Validators.required],
      mobile_number: ['',Validators.required],
      role_id: ['',Validators.required]
    });
    this.loadRoles();
    this.route.queryParams.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.loadEmployee(id);
      }
    });
  }

  // Load roles on component initialization
  public loadRoles(): void {
    this.createEmployeeService.getRoles().subscribe({
      next: (roles: EmployeeRole[]) => {
        this.roles = roles;
      },
      error: (error) => {
        console.error('Error loading roles:', error);
      }
    });
  }

  private createEmployee(employeeData: UserData): void {
    this.createEmployeeService.createEmployee(employeeData).subscribe({
      next: (response) => {
        // console.log('Employee created successfully!', response);    
        this.alertz ('success', response.msg,'/employee-list');
        this.resetForm();
      },
      
      error: (error) => {
        if (error.error && error.error.error) {
          this.mapErrorsToFields(error.error.error);
        } else {
          this.alertz ('error',error.error.error);
        }
      }
    });
  }
  
  private updateEmployee(employeeData: UserData): void {
    if (this.selectedEmployee) {
      this.createEmployeeService.updateEmployee(this.selectedEmployee.id, employeeData).subscribe({
        next: (response) => {
          // console.log("emp updated ==> =>", response)
          this.alertz ('success', response.msg,'/employee-list');
          this.resetForm();
        },
        error: (error) => {
          if (error.error && error.error.error) {
            this.mapErrorsToFields(error.error.error);
            console.log("update employees consoling => ", error.error.error);
          } else {
            this.alertz('error',error.error.error)
          }
        }
      });
    }
  }


  private mapErrorsToFields(errorMessage: string): void {
    console.log('Error message:', errorMessage);

    // Define keyword-based field mapping
    const errorFieldMapping: { [key: string]: string } = {
      'name': 'name',
      'address': 'address',
      'email': 'email',
      'mobile_number': 'mobile_number',
      'role_id': 'role_id',
    };

    // Split error message into words for comparison
    const errorWords = errorMessage.toLowerCase().split(/\s+/);

    for (const key in errorFieldMapping) {
      // Check if any word in error message matches the keyword
      if (errorWords.includes(key.toLowerCase())) {
        const field = errorFieldMapping[key];
        this.newEmployeeForm.get(field)?.setErrors({ backendError: errorMessage });
        this.fieldErrors[field] = errorMessage;
        this.focusField(field);
        console.log('field', field);
        return;
      }
      this.newEmployeeForm.setErrors({ backendError: errorMessage });
    }
  }

  private focusField(field: string): void {
    switch (field) {
      case 'name':
        this.nameInput.nativeElement.focus();
        break;
      case 'mobile_number':
        this.mobile_numberInput.nativeElement.focus();
        break;
      case 'address':
        this.addressInput.nativeElement.focus();
        break;
      case 'email':
        this.emailInput.nativeElement.focus();
        break;
      case 'role_id':
        this.roleidInput.open(); // Use open method for MatSelect Focus on role_id input        break;
        break;
    }
  }

  // form submitting 
  saveForm(): void {
    this.fieldErrors = {}; // Reset previous errors
    if (this.selectedEmployee) {
      this.updateEmployee(this.newEmployeeForm.value);
    } else {
      this.createEmployee(this.newEmployeeForm.value);
    }
  }

  resetForm(): void {
    this.newEmployeeForm.reset();
    if (!this.selectedEmployee) {
      this.selectedEmployee = null;
    }
    this.fieldErrors = {};
  }

  loadEmployee(id: string): void {
    this.createEmployeeService.getEmployeeById(id).subscribe({
      next: (employee: UserData) => {
        this.selectedEmployee = employee;
        this.newEmployeeForm.patchValue(employee);
        this.verificationMessage = employee.verify_email || ''; // Only set if message is present
      },
      error: (error) => {
        console.error('Error loading employee:', error);
      }
    });
  }

  alertz(kind:FuseAlertType,msg:string,route?:string): void{
    this.alert = { 
      type:kind,
      message:msg 
    };
    this.showAlert = true;
    this.cdr.markForCheck();
    setTimeout(() => {
       this.showAlert = false;
       this.router.navigate([route])
      },4000);
    }

}
