// src/app/modules/admin/employee-list/employee-list.routes.ts
import { Route } from '@angular/router';
import { EmployeeListComponent } from './employee-list.component';

export const employeeListRoutes: Route[] = [
    { path: '', component: EmployeeListComponent }
];
