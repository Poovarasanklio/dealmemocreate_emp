import { ChangeDetectionStrategy, Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef, ElementRef } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { CreateEmployeeService } from 'app/core/employee/employee.service';
import { UserData, EmployeeResponse } from 'app/core/employee/employee.types';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { TextFieldModule } from '@angular/cdk/text-field';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from 'app/shared folder/confirmation-dialog/confirmation-dialog.component';
import { Router, RouterModule } from '@angular/router';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { MatTooltip } from '@angular/material/tooltip';

@Component({
  selector: 'app-employee-list',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatIconModule,
    TextFieldModule,
    MatButtonModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    CommonModule,
    MatInputModule,
    MatDialogModule,
    FuseAlertComponent,
    RouterModule,
    MatTooltip 
  ],
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit, AfterViewInit {

  dataList = new MatTableDataSource<UserData>([]);
  displayedColumns: string[] = ['name', 'address', 'mobile_number', 'email', 'action'];
  loading: boolean = false; 
  showAlert: boolean = false;
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };
  noDataMessage: string = ''; // Message to display when no data is found

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('nameSearchInput') nameSearchInput: ElementRef;

  constructor(
    private router: Router,
    private createEmployeeService: CreateEmployeeService,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.loadEmployees();
  }

  ngAfterViewInit(): void {
    if (this.dataList) {
      this.dataList.paginator = this.paginator;
      this.dataList.sort = this.sort;
    }
  }

  filterEmployees(): void {
    const name = this.nameSearchInput.nativeElement.value.trim().toLowerCase();
    if (!name) {
      this.loadEmployees();
      return;
    }

    this.showAlert = false;
    this.loading = true;
    this.noDataMessage = ''; // Reset no data message

    this.createEmployeeService.filterEmployeesByName(name).subscribe({
      next: (response: EmployeeResponse) => {
        this.dataList.data = response.data;
        this.dataList.paginator = this.paginator;
        this.dataList.sort = this.sort;

        if (response.data.length === 0) {
          this.noDataMessage = `No results found for your search "${name}"`;
          this.dataList.data = []; // Reset dataList to an empty array
        }
      },
      error: error => {
        console.error('Error filtering employees by name:', error);
        this.alert={
          type:'error',
          message :'Failed to filter employees. Please try again later',
        }   
        this.showAlert =true;
        setTimeout(() => {
          this.showAlert = false;
          this.loadEmployees();
          this.cdr.markForCheck(); // Trigger change detection
        }, 4000);
      },
      complete: () => {
        this.loading = false;
        this.cdr.markForCheck();
      }
    });
  }

  loadEmployees(): void {
    this.loading = true;
    this.noDataMessage = ''; // Reset no data message

    this.createEmployeeService.getEmployees().subscribe({
      next: (response: EmployeeResponse) => {
        this.dataList.data = response.data;
        this.dataList.paginator = this.paginator;
        this.dataList.sort = this.sort;

        if (response.data.length === 0) {
          this.noDataMessage = 'No data available';
          this.dataList.data = []; // Reset dataList to an empty array
        }
      },
      error: error => {
        console.error('Error loading employees:', error);
      },
      complete: () => {
        this.loading = false;
        this.cdr.markForCheck();
      }
    });
  }

  deleteEmployee(employee: UserData): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '600px',
      data: { title: 'Delete Employee', message: `Are you sure you want to delete ${employee.name}?` }
    });
 
    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.createEmployeeService.deleteEmployee(employee.id).subscribe({
          next: (response) => {
            this.alert = {
              type: 'success',
              message: response.msg,
            };
            this.showAlert = true;
            this.cdr.markForCheck(); // Trigger change detection

            setTimeout(() => {
              this.showAlert = false;
              this.loadEmployees();
              this.cdr.markForCheck(); // Trigger change detection
            }, 4000);
          },
          error: (error) => {
            this.alert = {
              type: 'error',
              message: error.error.error,
            };
            this.showAlert = true;
            this.cdr.markForCheck(); // Trigger change detection

            setTimeout(() => {
              this.showAlert = false;
              this.cdr.markForCheck(); // Trigger change detection
            }, 4000);
          }
        });
      }
    });
  }

  resetPassword(employee: UserData): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '600px',
      data: {
        title: `Reset Password`,
        message: `Are you sure you want to reset the password for ${employee.name}?`,
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.createEmployeeService.resetPassword(employee.id).subscribe({
          next: (response) => {
            this.alert = {
              type: 'success',
              message: response.msg,
            };
            this.showAlert = true;
            this.cdr.markForCheck(); // Trigger change detection

            setTimeout(() => {
              this.showAlert = false;
              this.cdr.markForCheck(); // Trigger change detection
            }, 4000);
          },
          error: (error) => {
            this.alert = {
              type: 'error',
              message: error.error.error,
            };
            this.showAlert = true;
            this.cdr.markForCheck(); // Trigger change detection

            setTimeout(() => {
              this.showAlert = false;
              this.cdr.markForCheck(); // Trigger change detection
            }, 4000);
          }
        });
      }
    });
  }

  // addEmployee(): void {
  //   this.router.navigate(['/employee-form']);
  // }

  editEmployee(employee: UserData): void {
    this.router.navigate(['/employee-form'], { queryParams: { id: employee.id } });
  }
}
