// src/app/modules/admin/employee-form/employee-form.routes.ts
import { Route } from '@angular/router';
import { ClientsFormComponent } from './clients-form.component';
  
export const clientsFormRoutes: Route[] = [
    { path: '', component: ClientsFormComponent }
];




