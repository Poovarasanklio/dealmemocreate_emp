import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ClientsService } from 'app/core/clients/clients.service';
import { ClientsCategory, SubClientsReport } from 'app/core/clients/clients.types';

@Component({
  selector: 'app-clients-form',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TextFieldModule,
    FormsModule,
    MatButtonModule,
    CommonModule,
    FuseAlertComponent,
    RouterModule,
    MatCheckboxModule,
    MatSelectModule,
    MatOptionModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatPaginator,
  ],
  templateUrl: './clients-form.component.html',
  styleUrl: './clients-form.component.scss'
})
export class ClientsFormComponent {

  // variables
  subClientsList = new MatTableDataSource<SubClientsReport>([]);
  noDataMessage:string ;

  isEditMode: boolean = false;
  categories: ClientsCategory[] = [];
  roleId: number;
  clientsForm: FormGroup;
  showAlert = false;
  alert = { type: 'success', message: '' };

  displayedColumns: string[] = ['name', 'type'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private clientsService: ClientsService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.loadCategories();
  
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.roleId = +params['id'];
        this.isEditMode = true;
        this.fetchClientDetails(this.roleId);
        this.loadSubClients(this.roleId); // Load subclients when entering edit mode
      }
    });
  }
  

  initForm(): void {
    this.clientsForm = this.fb.group({
      client_name: ['', Validators.required],
      client_category_id: ['', Validators.required],
      contact_name: [''],
      email: [''],
      street_address: [''],
      city: [''],
      state: [''],
      zipcode: ['']
    });
  }

  loadCategories(): void {
    this.clientsService.getCategories().subscribe({
      next: (response) => {
        this.categories = response.data;
      },
      error: (error) => {
        this.alertz('error',error.error.error); 
        this.showAlert = true;
      }
    });
  }

  fetchClientDetails(id: number): void {
    this.clientsService.getClientById(id).subscribe({
      next: (client) => {
        // console.log('client patch',client);
        this.clientsForm.patchValue(client);
      },
      error: (error) => {
        this.alertz ('error', error.error.error);
      }
    });
  }

  resetForm(): void {
    this.clientsForm.reset();
  }

  onSubmit(event: Event): void {
    event.preventDefault();         
    const clientData = this.clientsForm.value;
    console.log('clientData',clientData);
    if (this.isEditMode) {
      this.clientsService.updateClient(this.roleId, clientData).subscribe({
        next: (response) => {
          this.alertz('success',response.msg,'/clients-list');
        },
        error: (error) => {
          this.alertz('error',error.error.error);        
        }
      });
    }
    else {    
      this.clientsService.createClient(clientData).subscribe({
      next: (response) => {
       this.alertz('success',response.msg,'/clients-list');
      },
      error: (error) => {
        this.alertz('error',error.error.error);
        }
        });
      }
    }

    loadSubClients(client_id: number): void {
      this.noDataMessage = ''; // Reset no data message    
      this.clientsService.getSubClients(client_id).subscribe({
        next: (response: { data: SubClientsReport[] | null | undefined }) => {
          // Check if response.data is defined and is an array
          if (response.data && Array.isArray(response.data)) {
            this.subClientsList.data = response.data;
            this.subClientsList.paginator = this.paginator;
            this.subClientsList.sort = this.sort;
    
            if (response.data.length === 0) {
              this.noDataMessage = 'No data available';
              // console.log("this.noDataMessage = 'No data available';")
              this.subClientsList.data = []; // Reset dataList to an empty array
            }
          } else {
            // Handle the case where data is not present or is not an array
            this.noDataMessage = 'No data available';
            // console.log("is not an array= 'No data available';")
            this.subClientsList.data = []; // Reset dataList to an empty array
          }
        },
        error: error => {
          console.error('Error loading subclients:', error);
          this.noDataMessage = 'Error loading data';
        }
      });
    }

    alertz(kind:FuseAlertType,msg:string,route?:string): void{
      this.alert = { 
        type:kind,
        message:msg 
      };
      this.showAlert = true;
      this.cdr.markForCheck();
      setTimeout(() => {
        this.showAlert = false;
        this.router.navigate([route])
        },4000);
      }
    
}
