// src/app/modules/admin/employee-form/employee-form.routes.ts
import { Route } from '@angular/router';
import { ClientsListComponent } from './clients-list.component';
 
export const clientsListRoutes: Route[] = [
    { path: '', component: ClientsListComponent }
];




