import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltip } from '@angular/material/tooltip';
import { Router, RouterModule } from '@angular/router';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';

import { ClientsService } from 'app/core/clients/clients.service';
import { ClientsCategory, ClientsReport, ClientsResponse } from 'app/core/clients/clients.types';
import { ConfirmationDialogComponent } from 'app/shared folder/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-clients-list',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatIconModule,
    TextFieldModule,
    MatButtonModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatPaginator,
    MatSelectModule,
    MatOptionModule,
    CommonModule,
    MatInputModule,
    MatDialogModule,
    RouterModule,
    MatTooltip ,
    FuseAlertComponent
  ],
  templateUrl: './clients-list.component.html',
  styleUrl: './clients-list.component.scss'
})
export class ClientsListComponent {

  clientsList = new MatTableDataSource<ClientsReport>([]);
  displayedColumns: string[] = ['client_name', 'category_name','contact_name','street_address', 'action'];
  selectedCategory: string = 'all';  // Holds the selected category
  categories: ClientsCategory[] = [];
  noDataMessage:string='';

  showAlert:boolean=false;
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('clientsInputName') clientsInputName!: ElementRef<HTMLInputElement>;
  @ViewChild('categorySelect') categorySelect!: any;

  constructor(
    private clientsService: ClientsService, 
    private dialog: MatDialog, 
    private router: Router,
    private cdr: ChangeDetectorRef){}

  ngOnInit(): void {
    this.loadClients();
    this.loadClientsCategory();
  }

    loadClients(): void {
      this.noDataMessage = ''; // Reset no data message

      this.clientsService.getClients().subscribe({
        next: (response: ClientsResponse) => {
          this.clientsList.data  = response.data;
          this.clientsList.paginator = this.paginator;
          this.clientsList.sort = this.sort;

          if (response.data.length === 0) {
            this.noDataMessage = 'No data available';
            this.clientsList.data = []; // Reset dataList to an empty array
          }
        },
        error: error => {
          console.error('Error loading employees:', error);
        }
      });
    }
    
    loadClientsCategory(): void {
      this.clientsService.getCategories().subscribe({
        next: (response) => {
          // console.log('resp =>',response);
          this.categories = response.data;
        },
        error: (error) => {
          this.alertz('error',error.error.error);
          }
      });
    }

    filterClients(): void {
      if (!this.clientsInputName || !this.categorySelect) {
        console.error('Inputs are not initialized.');
        return;
      }
  
      const artistName = (this.clientsInputName.nativeElement.value || '').trim().toLowerCase();
      const selectedCategory = this.categorySelect.value || '';
  
      this.clientsService.getFilteredClients({client_name: artistName,client_category_id: selectedCategory}).subscribe({
        next: (clients: ClientsResponse) => {
          this.clientsList.data = clients.data;
          this.clientsList.paginator = this.paginator;
          this.clientsList.sort = this.sort;
  
          if (clients.data.length === 0) {
            this.noDataMessage = 'No data available';
          } else {
            this.noDataMessage = '';
          }
        },
        error: (error) => {
          console.error('Error fetching clients:', error);
        }
      });
    }
    
    deleteClient(client: ClientsReport) {
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '600px',
        data: { title: 'Delete Artist', message: `Are you sure you want to delete the client: ${client.name}?` }
      });
      
      dialogRef.afterClosed().subscribe(result => {
        if (result === true) {
          this.clientsService.deleteClient(client.id).subscribe({
            next: (response: any) => {
              // console.log('Delete response:', response);
              // Filter out the deleted artist from the list
              this.clientsList.data = this.clientsList.data.filter(a => a.id !== client.id);
              this.alertz('success',response.msg);
            },
            error: (error) => {
              console.error('Error deleting client:', error);
              this.alertz('error',error.error.error);
              }                
          });
        }
      });
    }

    editClients(clients: ClientsReport) {
      this.router.navigate(['/clients-form'], { queryParams: { id: clients.id } });
   }

    alertz(kind:FuseAlertType,msg:string,route?:string): void{
      this.alert = { 
        type:kind,
        message:msg 
      };
      this.showAlert = true;
      this.cdr.markForCheck();
      setTimeout(() => {
         this.showAlert = false;
         this.router.navigate([route])
        },4000);
      }

}
