import { ChangeDetectionStrategy, Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, FormsModule, ReactiveFormsModule, FormArray, FormControl } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { EmployeeRoleService } from 'app/core/employee-role/employee-role.service';
import { ExRole, Permission, Role } from 'app/core/employee-role/employee-role.types';
import { MatCheckboxModule } from '@angular/material/checkbox';
 
@Component({
  selector: 'app-employee-role-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TextFieldModule,
    FormsModule,
    MatButtonModule,
    CommonModule,
    FuseAlertComponent,
    RouterModule,
    MatCheckboxModule
  ],
  templateUrl: './employee-role-form.component.html',
  styleUrls: ['./employee-role-form.component.scss']
})

export class EmployeeRoleFormComponent implements OnInit {
  roleId: number;
  permissions: Permission[] = [];
  assignedPermissions: any;
  newroleForm: FormGroup;

  isEditMode = false;
  showAlert: boolean = false;
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private permissionService: EmployeeRoleService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.route.queryParams.subscribe(params => {
      if (params.id) {
        this.roleId = +params.id;
        this.isEditMode = true;
        this.fetchRoleDetails();
      }
    });
    this.fetchPermissions();
  }

  initForm(): void {
    this.newroleForm = this.fb.group({
      name: [''],
      description: [''],
      permissions: this.fb.array([])
    });
  }

  fetchRoleDetails(): void {
    this.permissionService.getRoleById(this.roleId).subscribe(
      (role: ExRole) => {
        this.newroleForm.patchValue({
          name: role.name,
          description: role.description
        });

        const rolePermissions = [];
        if (role.permission_ids && typeof role.permission_ids === 'object') {
          Object.values(role.permission_ids).forEach((value: any) => {
            if (value) {
              rolePermissions.push(value);
            }
          });
        }
        this.assignedPermissions = rolePermissions;
        this.populatePermissions(this.assignedPermissions);
        this.cdr.markForCheck();
      },
      error => {
        console.error('Error fetching role details:', error);
      }
    );
  }

  fetchPermissions(): void {
    this.permissionService.getPermissions().subscribe(
      (permissions: Permission[]) => {
        this.permissions = permissions;
        if (this.assignedPermissions?.length > 0) {
          this.populatePermissions(this.assignedPermissions);
        } else {
          this.populatePermissions([]);
        }
        this.cdr.markForCheck();
      },
      error => {
        console.error('Error fetching permissions:', error);
      }
    );
  }

  populatePermissions(assignedPermissions: number[] = []): void {
    const permissionFormArray = this.newroleForm.get('permissions') as FormArray;
    permissionFormArray.clear();

    this.permissions.forEach(permission => {
      permissionFormArray.push(this.fb.group({
        id: [permission.id],
        name: [permission.name],
        completed: [assignedPermissions.includes(permission.id)]
      }));
    });
  }

  toggleCheckbox(index: number): void {
    const permissionFormGroup = this.permissionsFormArray.at(index) as FormGroup;
    const completedControl = permissionFormGroup.get('completed') as FormControl;
    completedControl.patchValue(!completedControl.value);
  }

  resetForm(): void {
    this.newroleForm.reset();
    this.permissionsFormArray.clear();
    this.populatePermissions();
  }

  get permissionsFormArray(): FormArray {
    return this.newroleForm.get('permissions') as FormArray;
  }

  onSubmit(event: Event): void {
    event.preventDefault(); // Prevent default form submission behavior
    if (this.isEditMode) {
      this.updateRole();
    } else {
      this.createRole();
    }
  }

  
   createRole(): void {
    const formData = this.newroleForm.value;

    // Extract selected permission IDs
    const selectedPermissions = formData.permissions
      .filter((permission: { completed: boolean; }) => permission.completed)
      .map((permission: { id: any; }) => permission.id);

    const payload = {
      name: formData.name,
      description: formData.description,
      permissions: selectedPermissions
    };

    this.permissionService.createRole(payload).subscribe({
      next: (response: any) => {
        console.log("Response:", response);
        this.alert = {
          type: 'success',
          message: response.msg,
        };
        this.showAlert = true;
        this.cdr.markForCheck(); // Mark for check after changing alert state
        setTimeout(() => {
          this.router.navigate(['/employee-role-list']);
          this.showAlert = false;
        }, 4000);
      },
      error: (error: any) => {
        console.error('Error creating role:', error);
        this.alert = {
          type: 'error',
          message: error.error.error,
        };
        this.showAlert = true;
        this.cdr.markForCheck(); // Mark for check after changing alert state
        setTimeout(() => {
          this.showAlert = false;
        }, 4000);
      }
    });
  }

  updateRole(): void {
    const formData = this.newroleForm.value;
    const selectedPermissions = formData.permissions
      .filter(permission => permission.completed)
      .map(permission => permission.id);

    const payload = {
      name: formData.name,
      description: formData.description,
      permissions: selectedPermissions
    };

    this.permissionService.updateRole(this.roleId, payload).subscribe({
      next: (response) => {
        console.log("Response:", response);
        this.alert = {
          type: 'success',
          message: response.msg,
        };
        this.showAlert = true;
        this.cdr.markForCheck(); // Mark for check after changing alert state
        setTimeout(() => {
          this.router.navigate(['/employee-role-list']);
          this.showAlert = false;
        }, 4000);
      },
      error: (error) => {
        console.error('Error updating role:', error.error.error);
        this.alert = {
          type: 'error',
          message: error.error.error,
        };
        this.showAlert = true;
        this.cdr.markForCheck(); // Mark for check after changing alert state
        setTimeout(() => {
          this.showAlert = false;
        }, 4000);
      }
    });
  }
}