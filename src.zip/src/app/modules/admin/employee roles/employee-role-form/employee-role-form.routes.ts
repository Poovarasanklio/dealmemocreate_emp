// src/app/modules/admin/employee-form/employee-form.routes.ts
import { Route } from '@angular/router';
import { EmployeeRoleFormComponent } from './employee-role-form.component';
 
export const employeeRoleFormRoutes: Route[] = [
    { path: '', component: EmployeeRoleFormComponent }
];




