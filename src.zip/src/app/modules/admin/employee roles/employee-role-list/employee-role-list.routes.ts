// src/app/modules/admin/employee-form/employee-form.routes.ts
import { Route } from '@angular/router';
import { EmployeeRoleListComponent } from './employee-role-list.component';
 
export const employeeRoleListRoutes: Route[] = [
    { path: '', component: EmployeeRoleListComponent }
];
