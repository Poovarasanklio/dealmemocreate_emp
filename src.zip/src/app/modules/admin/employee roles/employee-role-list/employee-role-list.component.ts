import { ChangeDetectionStrategy, Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef  } from '@angular/core';
import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator,MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { Router, RouterModule } from '@angular/router';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { EmployeeRoleService } from 'app/core/employee-role/employee-role.service';
import { Role } from 'app/core/employee-role/employee-role.types';
// import { ConfirmationDialogComponent } from 'app/shared folder/confirmation-dialog/confirmation-dialog.component';
import { MatTooltip } from '@angular/material/tooltip';
 
// dialog
import { FuseConfirmationService } from '@fuse/services/confirmation/confirmation.service';
import { FuseConfirmationConfig } from '@fuse/services/confirmation/confirmation.types';

@Component({
  selector: 'app-employee-role-list',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    MatIconModule,
    TextFieldModule,
    MatButtonModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    CommonModule,
    MatDialogModule,
    FuseAlertComponent,
    RouterModule,
    MatTooltip, 
  ],
  templateUrl: './employee-role-list.component.html',
  styleUrl: './employee-role-list.component.scss'
})
 
export class EmployeeRoleListComponent implements OnInit ,AfterViewInit{
      
      displayedColumns: string[] = ['name', 'description', 'action'];
      roleList = new MatTableDataSource<Role>();
      noDataMessage = 'No roles available.';
    
      @ViewChild(MatPaginator) paginator!: MatPaginator;
      @ViewChild(MatSort) sort!: MatSort;
      showAlert: boolean = false;
      alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
      };
    
      constructor(
        private router: Router,
        private roleService: EmployeeRoleService,
        private cdr: ChangeDetectorRef,
        private dialog: MatDialog,
        private confirmationService: FuseConfirmationService
      ) {}
    
      ngOnInit(): void {
        this.loadRoles();
      }
    
      ngAfterViewInit(): void {
        if (this.roleList) {
          this.roleList.paginator = this.paginator;
          this.roleList.sort = this.sort;
        }
      }
      
      loadRoles(): void {
        this.noDataMessage = ''; // Reset no data message
    
        this.roleService.getRoles().subscribe({
          next: (roles: Role[]) => {
            this.roleList.data = roles; // Directly assign roles
            this.roleList.paginator = this.paginator;
            this.roleList.sort = this.sort;
    
            if (roles.length === 0) {
              this.noDataMessage = 'No data available';
              this.roleList.data = []; // Reset roleList to an empty array
            }
          },
          error: (error) => {
            console.error('Error loading roles:', error);
            this.noDataMessage = 'Error loading roles.';
            this.roleList.data = []; // Clear data on error
          }
        });
      }
    
      deleteRole(role: Role) {

        const config: FuseConfirmationConfig = {
          title: 'Delete Role',
          message: `Are you sure you want to delete the role: ${role.name}?`,
          actions: {
              confirm: {
                  label: 'Delete',
                  color: 'warn'
              }
          }
      };

      // Open confirmation dialog
      const dialogRef = this.confirmationService.open(config);

      dialogRef.afterClosed().subscribe(result => {
          if (result === 'confirmed') {
        // jhkk
        // const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        //   width: '600px',
        //   data: { title: 'Delete Role', message: `Are you sure you want to delete the role: ${role.name}?` }
        // });
        
        
        // dialogRef.afterClosed().subscribe(result => {
        //   if (result === true) {
            this.roleService.deleteRole(role.id).subscribe({
              next: (response) => {
                // console.log('delete response =>',response);
                this.alertz('success',response.msg);
                // Filter out the deleted role from the list
                this.roleList.data = this.roleList.data.filter(r => r.id !== role.id);
                this.loadRoles();
              },
              error: (error) => {
                this.alertz('error',error.error.error);
              }
            });
          }
        });
      }
    
      editRole(role: Role): void {
        this.router.navigate(['/employee-role-form'], { queryParams: { id: role.id } });
      }

      alertz(kind:FuseAlertType,msg:string,route?:string): void{
        this.alert = { 
          type:kind,
          message:msg 
        };
        this.showAlert = true;
        this.cdr.markForCheck();
        setTimeout(() => {
           this.showAlert = false;
           this.router.navigate([route])
          },4000);
        }

    }
    