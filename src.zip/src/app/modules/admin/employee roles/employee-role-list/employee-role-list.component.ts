import { ChangeDetectionStrategy, Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef  } from '@angular/core';
import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator,MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { Router, RouterModule } from '@angular/router';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { EmployeeRoleService } from 'app/core/employee-role/employee-role.service';
import { Role } from 'app/core/employee-role/employee-role.types';
import { ConfirmationDialogComponent } from 'app/shared folder/confirmation-dialog/confirmation-dialog.component';
import { MatTooltip } from '@angular/material/tooltip';
 

@Component({
  selector: 'app-employee-role-list',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    MatIconModule,
    TextFieldModule,
    MatButtonModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    CommonModule,
    MatDialogModule,
    FuseAlertComponent,
    RouterModule,
    MatTooltip
  ],
  templateUrl: './employee-role-list.component.html',
  styleUrl: './employee-role-list.component.scss'
})
 
    export class EmployeeRoleListComponent implements OnInit ,AfterViewInit{
        loading:boolean = false;
      displayedColumns: string[] = ['name', 'description', 'action'];
      roleList = new MatTableDataSource<Role>();
      noDataMessage = 'No roles available.';
    
      @ViewChild(MatPaginator) paginator!: MatPaginator;
      @ViewChild(MatSort) sort!: MatSort;
      showAlert: boolean = false;
      alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
      };
    
      constructor(
        private router: Router,
        private roleService: EmployeeRoleService,
        private cdr: ChangeDetectorRef,
        private dialog: MatDialog,
      ) {}
    
      ngOnInit(): void {
        this.loadRoles();
      }
    
      ngAfterViewInit(): void {
        if (this.roleList) {
          this.roleList.paginator = this.paginator;
          this.roleList.sort = this.sort;
        }
      }
      
      loadRoles(): void {
        this.loading = true; // Start loading
        this.noDataMessage = ''; // Reset no data message
    
        this.roleService.getRoles().subscribe({
          next: (roles: Role[]) => {
            this.roleList.data = roles; // Directly assign roles
            this.roleList.paginator = this.paginator;
            this.roleList.sort = this.sort;
    
            if (roles.length === 0) {
              this.noDataMessage = 'No data available';
              this.roleList.data = []; // Reset roleList to an empty array
            }
          },
          error: (error) => {
            console.error('Error loading roles:', error);
            this.noDataMessage = 'Error loading   sdsaroles.';
            this.roleList.data = []; // Clear data on error
          },
          complete: () => {
            this.loading = false; // End loading
            this.cdr.markForCheck(); // Notify change detection for `OnPush` strategy
          }
        });
      }
    
      deleteRole(role: Role) {

        const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
          width: '600px',
          data: { title: 'Delete Role', message: `Are you sure you want to delete the role: ${role.name}?` }
        });
        
        
        dialogRef.afterClosed().subscribe(result => {
          if (result === true) {
            this.roleService.deleteRole(role.id).subscribe({
              next: (response) => {
                console.log('delete response =>',response);
                this.alert = {
                  type: 'success',
                  message: response.msg,
                };
                // Filter out the deleted role from the list
                this.roleList.data = this.roleList.data.filter(r => r.id !== role.id);
                this.showAlert = true;
                this.cdr.markForCheck(); // Trigger change detection
    
                setTimeout(() => {
                  this.showAlert = false;
                  this.loadRoles();
                  this.cdr.markForCheck(); // Trigger change detection
                }, 4000);
              },
              
              error: (error) => {
                this.alert = {
                  type: 'error',
                  message: error.error.error,
                };
                this.showAlert = true;
                this.cdr.markForCheck(); // Trigger change detection
    
                setTimeout(() => {
                  this.showAlert = false;
                  this.cdr.markForCheck(); // Trigger change detection
                }, 4000);
              }
            });
          }
        });

 
        
      }


    
      editRole(role: Role): void {
        this.router.navigate(['/employee-role-form'], { queryParams: { id: role.id } });
      }

    }
    