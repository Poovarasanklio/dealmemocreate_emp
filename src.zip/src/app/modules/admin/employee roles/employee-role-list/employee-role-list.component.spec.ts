import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRoleListComponent } from './employee-role-list.component';

describe('EmployeeRoleListComponent', () => {
  let component: EmployeeRoleListComponent;
  let fixture: ComponentFixture<EmployeeRoleListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmployeeRoleListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmployeeRoleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
