// src/app/modules/admin/employee-form/employee-form.routes.ts
import { Route } from '@angular/router';
 import { ArtistsFormComponent } from './artists-form.component';
 
export const artistsFormRoutes: Route[] = [
    { path: '', component: ArtistsFormComponent }
];




