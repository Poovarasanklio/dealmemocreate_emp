import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ArtistsService } from 'app/core/artists/artists.service';
import { ArtistCategory } from 'app/core/artists/artists.types';

@Component({
  selector: 'app-artists-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TextFieldModule,
    FormsModule,
    MatButtonModule,
    CommonModule,
    FuseAlertComponent,
    RouterModule,
    MatCheckboxModule,
    MatSelectModule,
    MatOptionModule],
  templateUrl: './artists-form.component.html',
  styleUrl: './artists-form.component.scss'
})

export class ArtistsFormComponent implements OnInit {
  
  // variables
  isEditMode: boolean = false;
  categories: ArtistCategory[] = [];
  roleId: number;
  artistsForm: FormGroup;
  showAlert = false;
  alert = { type: 'success', message: '' };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private artistsService: ArtistsService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.loadCategories();

    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.roleId = +params['id'];
        this.isEditMode = true;
        this.fetchArtistDetails(this.roleId);
      }
    });
  }

  initForm(): void {
    this.artistsForm = this.fb.group({
      artist_name: ['', Validators.required],
      artist_category_id: ['', Validators.required],
      business_name: [''],
      email: [''],
      street_address: [''],
      city: [''],
      state: [''],
      zipcode: ['']
    });
  }

  loadCategories(): void {
    this.artistsService.getCategories().subscribe({
      next: (response) => {
        this.categories = response.data;
      },
      error: (error) => {
        this.alertz('error',error.error.error); 
        this.showAlert = true;
      }
    });
  }

  fetchArtistDetails(id: number): void {
    this.artistsService.getArtistById(id).subscribe({
      next: (artist) => {
        // console.log('artist patch',artist);
        this.artistsForm.patchValue(artist);
      },
      error: (error) => {
        this.alertz ('error', error.error.error );
        this.showAlert = true;
      }
    });
  }

  resetForm(): void {
    this.artistsForm.reset();
  }

  onSubmit(event: Event): void {
    event.preventDefault();
    const artistData = this.artistsForm.value;
    // console.log('artistData',artistData);
    if (this.isEditMode) {
      this.artistsService.updateArtist(this.roleId, artistData).subscribe({
        next: (response) => {
          this.alertz('success',response.msg,'/artists-list');
        },
        error: (error) => {
          this.alertz('error',error.error.error);        
        }
      });
    }
    else{
    this.artistsService.createArtist(artistData).subscribe({
      next: (response) => {
       this.alertz('success',response.msg,'/artists-list');
      },
      error: (error) => {
        this.alertz('error',error.error.error);
        }
        });
        
      }
    }


    alertz(kind:FuseAlertType,msg:string,route?:string): void{
      this.alert = { 
        type:kind,
        message:msg 
      };
      this.showAlert = true;
      this.cdr.markForCheck();
      setTimeout(() => {
         this.showAlert = false;
         this.router.navigate([route])
        },4000);
      }
  }
  
    


