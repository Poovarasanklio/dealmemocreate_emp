import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild  } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInput, MatInputModule } from '@angular/material/input';
import { MatPaginator,MatPaginatorModule } from '@angular/material/paginator';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltip } from '@angular/material/tooltip';
import { Router, RouterModule } from '@angular/router';
 
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ArtistsService } from 'app/core/artists/artists.service';
import { ArtistCategory, ArtistsReport, ArtistsResponse } from 'app/core/artists/artists.types';
import { ConfirmationDialogComponent } from 'app/shared folder/confirmation-dialog/confirmation-dialog.component';
 
@Component({
  selector: 'app-artists-list',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatFormFieldModule,
    MatIconModule,
    TextFieldModule,
    MatButtonModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatPaginator,
    MatSelectModule,
    MatOptionModule,
    CommonModule,
    MatInputModule,
    MatDialogModule,
    RouterModule,
    MatTooltip ,
    FuseAlertComponent
   ],
  templateUrl: './artists-list.component.html',
  styleUrl: './artists-list.component.scss'
})
export class ArtistsListComponent implements OnInit{

  artistsList = new MatTableDataSource<ArtistsReport>([]);
  displayedColumns: string[] = ['name', 'category', 'action'];
  categories: ArtistCategory[] = [];
  // ArtistsList: ArtistsReport[] = [];
  selectedCategory: string = 'all';  // Holds the selected category

  showAlert:boolean=false;
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };
  artistName: string = '';  // Holds the input for artist's name
  loading: boolean;
  
  noDataMessage:string='';
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('artistNameInput') artistNameInput!: ElementRef<HTMLInputElement>;
  @ViewChild('categorySelect') categorySelect!: any;
  
   

  constructor(private artistsService: ArtistsService, private dialog: MatDialog, private router: Router,private cdr: ChangeDetectorRef){}

  ngOnInit(): void {
    this.loadArtists();
    this.loadCategories();
  }

    loadArtists(): void {
      this.loading = true;
      this.noDataMessage = ''; // Reset no data message

      this.artistsService.getArtists().subscribe({
        next: (response: ArtistsResponse) => {
          this.artistsList.data  = response.data;
          this.artistsList.paginator = this.paginator;
          this.artistsList.sort = this.sort;

          if (response.data.length === 0) {
            this.noDataMessage = 'No data available';
            this.artistsList.data = []; // Reset dataList to an empty array
          }
        },
        error: error => {
          console.error('Error loading employees:', error);
        },
        complete: () => {
          this.loading = false;
        
        }
      });
    }

     

    loadCategories(): void {
      this.artistsService.getCategories().subscribe({
        next: (response) => {
          console.log('resp =>',response);
          
          this.categories = response.data;
        },
        error: (error) => {
          this.alert = {
            type: 'error',
            message: 'Failed to load categories.'
          };
          this.showAlert = true;
        }
      });
    }
  
     
    filterArtists(): void {
      if (!this.artistNameInput || !this.categorySelect) {
        console.error('Inputs are not initialized.');
        return;
      }
  
      const artistName = (this.artistNameInput.nativeElement.value || '').trim().toLowerCase();
      const selectedCategory = this.categorySelect.value || '';
  
      this.artistsService.getFilteredArtists({
        artist_name: artistName,
        artist_category_id: selectedCategory
      }).subscribe({
        next: (artists: ArtistsResponse) => {
          this.artistsList.data = artists.data;
          this.artistsList.paginator = this.paginator;
          this.artistsList.sort = this.sort;
  
          if (artists.data.length === 0) {
            this.noDataMessage = 'No data available';
          } else {
            this.noDataMessage = '';
          }
        },
        error: (error) => {
          console.error('Error fetching artists:', error);
        }
      });
    }
    
    deleteArtists(artist: ArtistsReport) {
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '600px',
        data: { title: 'Delete Artist', message: `Are you sure you want to delete the artist: ${artist.name}?` }
      });
      
      dialogRef.afterClosed().subscribe(result => {
        if (result === true) {
          this.artistsService.deleteArtist(artist.id).subscribe({
            next: (response: any) => {
              console.log('Delete response:', response);
              
              // Filter out the deleted artist from the list
              this.artistsList.data = this.artistsList.data.filter(a => a.id !== artist.id);
              this.alertz('success',response.msg);
              
            },
            error: (error) => {
              console.error('Error deleting artist:', error);
              this.alert = {
                type: 'error',
                message: error.error.error,
              };
              this.showAlert = true;
              
  
              setTimeout(() => {
                this.showAlert = false;
              }, 4000);
            }
          });
        }
      });
    }

    editArtists(artists: ArtistsReport) {
       this.router.navigate(['/artists-form'], { queryParams: { id: artists.id } });
    }

    alertz(kind:FuseAlertType,msg:string,route?:string): void{
      this.alert = { 
        type:kind,
        message:msg 
      };
      this.showAlert = true;
      this.cdr.markForCheck();
      setTimeout(() => {
         this.showAlert = false;
         this.router.navigate([route])
        },4000);
      }

    }

    



 