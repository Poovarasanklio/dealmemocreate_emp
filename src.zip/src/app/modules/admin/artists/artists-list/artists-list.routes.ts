// src/app/modules/admin/employee-form/employee-form.routes.ts
import { Route } from '@angular/router';
import { ArtistsListComponent } from './artists-list.component';
 
export const artistsListRoutes: Route[] = [
    { path: '', component: ArtistsListComponent }
];




