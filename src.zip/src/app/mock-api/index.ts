import { AuthMockApi } from 'app/mock-api/common/auth/api';

export const mockApiServices = [
    AuthMockApi
];
