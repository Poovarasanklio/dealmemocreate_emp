import { Route } from '@angular/router';
import { initialDataResolver } from 'app/app.resolvers';
import { AuthGuard } from 'app/core/auth/guards/auth.guard';
import { NoAuthGuard } from 'app/core/auth/guards/noAuth.guard';
import { LayoutComponent } from 'app/layout/layout.component';

// @formatter:off
/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
export const appRoutes: Route[] = [

    // Redirect empty path to '/example'
    { path: '', pathMatch: 'full', redirectTo: 'example' },

    // Redirect signed-in user to the '/example'
    //
    // After the user signs in, the sign-in page will redirect the user to the 'signed-in-redirect'
    // path. Below is another redirection for that path to redirect the user to the desired
    // location. This is a small convenience to keep all main routes together here on this file.
    { path: 'signed-in-redirect', pathMatch: 'full', redirectTo: 'example' },

    // Auth routes for guests
    {
        path: '',
        canActivate: [NoAuthGuard],
        canActivateChild: [NoAuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            { path: 'forgot-password', loadChildren: () => import('app/modules/auth/forgot-password/forgot-password.routes') },
            { path: 'reset-password', loadChildren: () => import('app/modules/auth/reset-password/reset-password.routes') },
            { path: 'sign-in', loadChildren: () => import('app/modules/auth/sign-in/sign-in.routes') },
        ]
    },

    // Auth routes for authenticated users
    {
        path: '',
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            { path: 'sign-out', loadChildren: () => import('app/modules/auth/sign-out/sign-out.routes') },
        ]
    },

    // Landing routes
    {
        path: '',
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            { path: 'home', loadChildren: () => import('app/modules/landing/home/home.routes') },
        ]
    },

    // Admin routes
    {
        path: '',
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            { path: 'example', loadChildren: () => import('app/modules/admin/example/example.routes') },
            { path: 'employee-list', loadChildren: () => import('app/modules/admin/employee/employee-list/employee-list.routes').then(m => m.employeeListRoutes) },
            { path: 'employee-form', loadChildren: () => import('app/modules/admin/employee/employee-form/employee-form.routes').then(m => m.employeeFormRoutes)
            },
            { path: 'employee-role-list', loadChildren: () => import('app/modules/admin/employee roles/employee-role-list/employee-role-list.routes').then(m => m.employeeRoleListRoutes)
            },
            { path: 'employee-role-form', loadChildren: () => import('app/modules/admin/employee roles/employee-role-form/employee-role-form.routes').then(m => m.employeeRoleFormRoutes)
            },
            { path: 'artists-list', loadChildren: () => import('app/modules/admin/artists/artists-list/artists-list.routes').then(m => m.artistsListRoutes)
            },
            { path: 'artists-form', loadChildren: () => import('app/modules/admin/artists/artists-form/artists-form.routes').then(m => m.artistsFormRoutes)
            },
            { path: 'clients-list', loadChildren: () => import('app/modules/admin/clients/clients-list/clients-list.routes').then(m => m.clientsListRoutes)
            },
            { path: 'clients-form', loadChildren: () => import('app/modules/admin/clients/clients-form/clients-form.routes').then(m => m.clientsFormRoutes)
            }
            
        ]
    }
];
